/*

	Scripts used by topics
	
*/

function initialize() {	// runs onload on all topic pages
	// inverted frameblaster: deploy!
	if (top.document.location.href == document.location.href) {	// we're missing the sidebar
		top.document.location.href = "../start.htm?topic="+document.location.href;
	}
}


// QueryString() & QueryString_Parse courtesy of http://javascript.about.com/library/scripts/blquerystring.htm
function QueryString(key)
{
	var value = null;
	for (var i=0;i<QueryString.keys.length;i++)
	{
		if (QueryString.keys[i]==key)
		{
			value = QueryString.values[i];
			break;
		}
	}
	return value;
}
QueryString.keys = new Array();
QueryString.values = new Array();

function QueryString_Parse()
{
	var query = top.window.location.search.substring(1);	// changed from window.location
	var pairs = query.split("&");
	
	for (var i=0;i<pairs.length;i++)
	{
		var pos = pairs[i].indexOf('=');
		if (pos >= 0)
		{
			var argname = pairs[i].substring(0,pos);
			var value = pairs[i].substring(pos+1);
			QueryString.keys[QueryString.keys.length] = argname;
			QueryString.values[QueryString.values.length] = value;		
		}
	}

}
QueryString_Parse();
